//PUT THIS LINE IN YOUR XEX XML FILE AND TAKE OUT YOUR OLD ONE

<section file="teapot.xzp" name="Teapot" memory="RO"/>

//NOW HERE IS THE CUSTOM SCENE LINES

Top Right:
  txtAd = Text Advertisement (TeapotLive.us)

Line1:
  txtSH = Text Status Header (Status:)
  txtS = Text Status Value (Authenticated)
  
Line2:
  txtDH = Text Days Header (Days:)
  txtD = Text Days Value (%d Day(s))
  txtKH1 = Text KV Header 1 (KV Used On:)
  txtK1 = Text KV Value 1 (%d Console(s))
  
Line3:
  txtEH = Text Expire Header (Time Remaining:)
  txtE = Text Expire (%hs)
  
Line4:
  txtKH1 = Text KV Header (KV Used On:)
  txtK1 = Text KV Value (%d Console(s))

//NOW KEEP IN MIND THESE ARE ALL BLANK BY DEFAULT SO THEY NEED TO BE SET

//HERE IS THE INITIAL FUNCTION TO CREATE ALL THE HOOKS JUST NEED TO CALL IT ONCE ON BOOT!

VOID DoCustomHudShit(){
	WCHAR tmp[40], tmp1[40];
	swprintf(tmp, L"section://%08X,Synd2#Teapot.xur", dllModule);
	swprintf(tmp1, L"section://%08X,Synd2#GuideMain.xur", dllModule);
	XuiLoadVisualFromBinary(tmp, NULL);
	XuiLoadVisualFromBinary(tmp1, NULL);

	PatchInJump((DWORD*)ResolveFunction(MODULE_XAM, 0x31F), (DWORD)XamBuildXamResourceLocatorHook, false);
	PatchInJump((DWORD*)ResolveFunction(MODULE_XAM, 0x31D), (DWORD)XamBuildGamercardResourceLocatorHook, false);
	PatchModuleImport("hud.xex", "xam.xex", 855, (DWORD)XuiSceneCreateHook);
}

//NOW PLACE THESE HOOKS IN

VOID XamBuildXamResourceLocatorHook(PWCHAR pResource, PWCHAR pBuffer, DWORD dwSize) {
	if (lstrcmpW(pResource, L"notify.xur") == 0) {
		swprintf(pBuffer, L"section://%08X,Teapot#notify.xur", GetModuleHandle("Teapot.xex"));
	} else {
		XamBuildResourceLocator(hXam, L"xam", pResource, pBuffer, dwSize);
	}
}

VOID XamBuildGamercardResourceLocatorHook(PWCHAR pResource, PWCHAR pBuffer, DWORD dwSize){
	if (lstrcmpW(pResource, L"GamerCard.xur") == 0) {
		swprintf(pBuffer, L"section://%08X,Teapot#GamerCard.xur", dllModule);
	} else {
		XamBuildResourceLocator(hXam, L"gamercrd", pResource, pBuffer, dwSize);
	}
}

HRESULT XuiSceneCreateHook(PWCHAR base, PWCHAR scene, void* init, HXUIOBJ* hscene){
	//make comparators
	WCHAR cmp1[64], cmp2[64];
	swprintf(cmp1, L"section://%08X,Teapot#GuideMain_Teapot.xur", dllModule);//used for child scenes
	if(lstrcmpW(scene, L"GuideMain.xur") == 0){ //compare for initial guide
		XuiSceneCreate(NULL, cmp1, init, hscene); //create custom guide scene
		//custom text under hud scene
		swprintf(cmp2, L"section://%08X,Teapot#TeapotCustom.xur", dllModule);
		XuiSceneCreate(NULL, cmp2, NULL, &customScene);
		XuiElementAddChild(*hscene, customScene); //add custom scene as child to guide
		DoCustomXui(customScene); //update our xui shit (DO CUSTOM REQUEST HERE)

	} else if (lstrcmpW(base, cmp1) == 0){ //child scene
		//remap to original hud location
		XuiSceneCreate(L"section://@0,hud#", scene, init, hscene);

		if(lstrcmpW(scene, L"SettingsTabSignedIn.xur") == 0 || lstrcmpW(scene, L"SettingsTabSignedOut.xur") == 0){
			HXUIOBJ child; DWORD id;
			if(XuiElementGetChildById(*hscene, L"btnFamilySettings", &child) == 0){ //BETTER HOOK THAN THE TEXT MODIFY SHIT
				XUIElementPropVal prop;
				XUIElementPropVal_Construct(&prop);
				XUIElementPropVal_SetString(&prop, L"Teapot Menu");
				if(XuiObjectGetPropertyId(child, L"Text", &id) == 0){
					XuiObjectSetProperty(child, id, NULL, &prop);
				}
				XUIElementPropVal_Destruct(&prop);
			}
			
		}
	} else {
		//whatever else...
		XuiSceneCreate(base, scene, init, hscene);

	}
	return 0;
}

//NOW HERE IS WHERE WE WILL DO ALL THE CUSTOM XUI TEXT

VOID DoCustomXui(HXUIOBJ obj){
	//this is an example
  HXUIOBJ childStatusHeader;
  if(XuiElementGetChildById(obj, L"txtSH", &childStatusHeader) == 0){
		XuiTextElementSetText(childStatusHeader, L"Status:");
	}

	HXUIOBJ childAd;
	if(XuiElementGetChildById(obj, L"txtAd", &childAd) == 0){
		XuiTextElementSetText(childAd, L"TeapotLive.us");
	}

  BOOL lifetime = TRUE;
	if(lifetime){
		//status value
		HXUIOBJ childStatus;
		if(XuiElementGetChildById(obj, L"txtS", &childStatus) == 0){
			XuiTextElementSetText(childStatus, L"Lifetime <3");
		}
  }
}

//FEEL FREE TO ASK QUESTIONS

